<?php get_header(); ?>

<!-- Hero -->
    <section class="hero">

    <div class="hero-overlay"></div>

    <div class="container-fluid h-100">
        <div class="row h-100">

            <!-- Left Side -->
            <div class="col-lg-6 d-flex align-items-center ps-lg-5">
                <div class="hero-content px-5">

                    <h1>Entry Doors</h1>

                    <p>
                        Architecturally inspired entry doors crafted for contemporary Australian homes
                    </p>

                    <a href="<?php echo esc_url(home_url('/product-category/external-doors/')); ?>" class="btn-custom">
    Shop Entry Doors
</a>
                </div>
            </div>

            <!-- Right Side -->
            <div class="col-lg-6 d-flex align-items-center ps-lg-5">
                <div class="hero-content px-5">

                    <h1>Internal Doors</h1>

                    <p>
                        Thoughtfully designed internal doors that elevate your home from the inside out
                    </p>

                    <a href="<?php echo esc_url(home_url('/product-category/internal-doors/')); ?>" class="btn-custom">
                        Shop Internal Doors
                    </a>

                </div>
            </div>

        </div>
    </div>

</section>

<section class="about-section">
    <div class="container">

        <div class="row align-items-center g-5">

            <!-- Image -->
            <div class="col-lg-7">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/about-door.jpg"
                     alt="Shield Doors"
                     class="img-fluid rounded-2 w-100">
            </div>

            <!-- Content -->
            <div class="col-lg-5">

                <span class="section-subtitle">
                    ABOUT SHIELD DOORS AND WINDOWS
                </span>

                <h2 class="section-title mt-3 mb-4">
                    Welcome To Shield.
                </h2>

                <p class="section-text">
                    Shield Doors and Windows supply home owners, builders,
                    DIYers and everyone else with quality timber unhung doors.
                    We buy directly from the manufacture cutting out costly
                    wholesalers and middlemen. With free
                    <strong><u>Australia wide shipping</u></strong>
                    on all orders over $550 there's never been a better time
                    to buy a timber door!
                </p>

                <a href="<?php echo esc_url(home_url('/about/')); ?>" class="btn-dark-custom mt-4">
                    More About Us
                </a>

            </div>

        </div>

    </div>
</section>

<section class="category-section">
    <div class="container-fluid px-lg-5">

        <h2 class="section-title mb-4">
            Shop by Category
        </h2>

        <div class="row g-3">

            <!-- Timber Doors -->
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo esc_url(home_url('/product-category/timber-doors/')); ?>" class="category-card">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/timber-door.jpg" alt="Timber Doors" class="img-fluid">
                    <div class="overlay-title">
                        Timber Doors
                    </div>
                </a>
            </div>

            <!-- Entry Doors -->
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo esc_url(home_url('/product-category/external-doors/')); ?>" class="category-card">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/entry-door.jpg" alt="Entry Doors" class="img-fluid">
                    <div class="overlay-title">
                        Entry Doors
                    </div>
                </a>
            </div>

            <!-- Internal Doors -->
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo esc_url(home_url('/product-category/internal-doors/')); ?>" class="category-card">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/internal-door.jpg" alt="Internal Doors" class="img-fluid">
                    <div class="overlay-title">
                        Internal Doors
                    </div>
                </a>
            </div>

        </div>

        <div class="row g-3 mt-1">

            <!-- Timber Doors -->
            <div class="col-lg-4 col-md-6">
                <a href="#" class="category-card">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/externalglass-door.jpg" alt="External Glass Doors" class="img-fluid">
                    <div class="overlay-title">
                        External Glass Doors
                    </div>
                </a>
            </div>

            <!-- Entry Doors -->
            <div class="col-lg-4 col-md-6">
                <a href="#" class="category-card">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/glazed-door.jpg" alt="Glazed Doors" class="img-fluid">
                    <div class="overlay-title">
                        Glazed Doors
                    </div>
                </a>
            </div>

            <!-- Internal Doors -->
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo esc_url(home_url('/product-category/aluminium/')); ?>" class="category-card">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/aluminium-door.jpg" alt="Aluminium Windows & Doors" class="img-fluid">
                    <div class="overlay-title">
                        Aluminium Windows & Doors
                    </div>
                </a>
            </div>

        </div>

    </div>
</section>

<!-- BEST SELLERS -->

<section class="bestsellers-section">

    <div class="container">

        <!-- Section Header -->
        <div class="row align-items-center mb-5">

            <div class="col-lg-8 col-md-7">
                <h2 class="section-title mb-0">
                    Our Best Selling Timber Doors
                </h2>
            </div>

            <div class="col-lg-4 col-md-5 text-md-end mt-3 mt-md-0">
                <a href="<?php echo site_url('/best-sellers/'); ?>" class="btn-dark-custom">
                  View All Best Sellers
                </a>
            </div>

        </div>

        <!-- Products -->
        <div class="row g-4">

            <?php
            $args = array(
    'post_type'      => 'product',
    'posts_per_page' => 4,
    'post_status'    => 'publish',
    'tax_query'      => array(
        array(
            'taxonomy' => 'product_visibility',
            'field'    => 'name',
            'terms'    => 'featured',
        ),
    ),
);

            $query = new WP_Query($args);

            if ($query->have_posts()) :

                while ($query->have_posts()) :
                    $query->the_post();

                    global $product;
            ?>

                <div class="col-lg-3 col-md-6">

                    <div class="card product-card h-100 border-0">

                        <a href="<?php the_permalink(); ?>">

                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium', array(
                                    'class' => 'card-img-top img-fluid'
                                )); ?>
                            <?php endif; ?>

                        </a>

                        <div class="card-body text-center">

                            <h5 class="product-title>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h5>

                            <div class="product-price">
                                <?php echo $product->get_price_html(); ?>
                            </div>

                        </div>

                    </div>

                </div>

            <?php
                endwhile;

                wp_reset_postdata();

            endif;
            ?>

        </div>

    </div>

</section>


<!-- IMAGE + CONTENT -->

<section class="content-section">
    <div class="container">

        <div class="row align-items-center g-5">

            <!-- Image -->
            <div class="col-lg-7">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/timber-doors.jpg"
                     alt="Timber Doors"
                     class="img-fluid rounded-2 w-100">
            </div>

            <!-- Content -->
            <div class="col-lg-5">

                <span class="section-subtitle">
                    SHIELD DOORS AND WINDOWS
                </span>

                <h2 class="section-title mt-3 mb-4">
                    Timber Doors
                </h2>

                <p class="section-text">
                    Make an instant statement with your solid core entry doors. Crafted from a range of American hardwood Shield Doors and Windows offer a range of timber doors in a refined list of stunning exterior doors.
                </p>

                <a href="#" class="btn-dark-custom mt-4">
                    Shop Timber Doors
                </a>

            </div>

        </div>

    </div>
</section>


<!-- BEST SELLERS -->

<section class="bestsellers-section">

    <div class="container">

        <div class="row align-items-center mb-5">

    <div class="col-lg-8 col-md-7">
        <h2 class="section-title mb-0">
            Interior Doors
        </h2>
    </div>

</div>

        <div class="row g-4">

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

        </div>

    </div>

</section>

<!-- IMAGE + CONTENT -->

<section class="content-section">
    <div class="container">

        <div class="row align-items-center g-5">

            <!-- Content -->
            <div class="col-lg-5">

                <span class="section-subtitle">
                    CUSTOM RANGE AVAILABLE
                </span>

                <h2 class="section-title mt-3 mb-4">
                    Aluminium Windows & Doors.
                </h2>

                <p class="section-text">
                    Bringing clean, modern lines to your home or office with our double-glazed Aluminium windows and doors.
Our Aluminium windows and doors are designed for Australian conditions allowing low maintenance whilst keeping the modern look for years to come. With options to help suit your design, view the Aluminium Windows and Aluminium Doors today
                </p>

                <a href="#" class="btn-dark-custom mt-4">
                    Aluminium Windows and Doors
                </a>

            </div>

            <!-- Image -->
            <div class="col-lg-7">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/Aluminium_Window.jpg"
                     alt="Timber Doors"
                     class="img-fluid rounded-2 w-100">
            </div>

        </div>

    </div>
</section>

<section class="timber-info-section">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-lg-10 text-center">

                <h2 class="section-title mb-4">
                    Timber Doors Australia
                </h2>

                <p class="timber-text">
                    Welcome to Shield Windows and Doors. Your Timber Door experts,
                    with stores located in Tasmania, Melbourne and Brisbane.
                </p>

                <p class="timber-text">
                    Discover premium <a href="#">Timber Doors</a> crafted to elevate
                    every home with timeless style and durability. Our quality Doors
                    are designed to combine strength, security and lasting performance.
                    Explore our range of Entry Doors and Front Door that create a
                    striking first impression. Each design balances modern appeal
                    with classic craftsmanship.
                </p>

                <p class="timber-text">
                    Enhance your interiors with beautifully finished Internal Doors,
                    built for everyday living. Choose styles that complement both
                    contemporary and traditional spaces. Shop trusted Brisbane doors,
                    Melbourne Doors and Hobart doors, made to suit Australian homes
                    and conditions with reliable quality you can depend on.
                </p>

                <a href="#" class="btn-dark-custom mt-4">
                    View The Full Range Of Timber Doors
                </a>

            </div>
        </div>

    </div>
</section>

<!-- BEST SELLERS -->

<section class="bestsellers-section">

    <div class="container">

        <div class="row align-items-center mb-5">

    <div class="col-lg-8 col-md-7">
        <h2 class="section-title mb-0">
            All Aluminium Products
        </h2>
    </div>

</div>

        <div class="row g-4">

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

        </div>

    </div>

</section>

<!-- CTA -->

<section class="cta-banner">

    <div class="container text-center cta-content">

        <h2>
            Not Sure What Door You Need?
        </h2>
        <p>Talk with our doorologit's today</p>

        <a href="#" class="btn btn-light btn-lg">
            Email Or Call
        </a>

    </div>

</section>

<!-- BEST SELLERS -->

<section class="bestsellers-section">

    <div class="container">

        <div class="row align-items-center mb-5">

    <div class="col-lg-8 col-md-7">
        <h2 class="section-title mb-0">
            Products for You
        </h2>
    </div>

</div>

        <div class="row g-4">

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

            <div class="col-lg-3 col-md-6">
                <a href="product-details.html">
                <div class="card product-card">
                    <img src="images/p1.jpg">
                    <div class="card-body">
                        <h5>White Oak Mexicano</h5>
                        <p>$350 - $450</p>
                    </div>
                </div>
                </a>
            </div>

        </div>

    </div>

</section>

<!-- meranti door section -->
    <section class="hero">

    <div class="hero-overlay"></div>

    <div class="container-fluid h-100">
        <div class="row h-100">

            <!-- Content -->
            <!-- Left Side -->
            <div class="col-lg-6 d-flex align-items-center ps-lg-5">
                <div class="hero-content px-5">

                    <p>
                        Customer Favourites
                    </p>

                    <h1>Meranti 4 Panel Front Timber Door</h1>

                    <p>
                        An Entry Door - Fit For Your Home.
                    </p>

                    <a href="#" class="btn-custom">
                        Shop Entry Doors
                    </a>

                </div>
            </div>

        </div>
    </div>

</section>

<section class="popular-doors-section">
    <div class="container-fluid px-lg-5">

        <div class="row align-items-center">

            <!-- Left Content -->
            <div class="col-lg-5">

                <span class="section-subtitle">
                    SHOP THE RANGE
                </span>

                <h2 class="section-title mt-3 mb-4">
                    The Latest & Most Popular Doors
                </h2>

                <p class="section-text mb-4">
                    Explore the latest range in Timber Doors, Glass Doors and
                    Barn Doors. From Four Panel Doors to Shaker Doors - We've
                    got the product suited for your next build.
                </p>

                <div class="door-links">

    <a href="glazed-doors.html"
       class="door-link active"
       data-image="<?php echo get_template_directory_uri(); ?>/assets/images/glazed-door.jpg"
       data-text="Beautiful glazed doors designed to maximize natural light and modern aesthetics.">
        Glazed Doors
    </a>

    <a href="timber-doors.html"
       class="door-link"
       data-image="<?php echo get_template_directory_uri(); ?>/assets/images/timber-door.jpg"
       data-text="Premium timber doors crafted from high-quality natural wood for lasting durability.">
        Timber Doors
    </a>

    <a href="barn-doors.html"
       class="door-link"
       data-image="<?php echo get_template_directory_uri(); ?>/assets/images/barn-door.jpg"
       data-text="Stylish barn doors perfect for contemporary and rustic interiors.">
        Barn Doors
        <span class="arrow">&#8250;</span>
    </a>

</div>

<p class="door-description mt-4">
    Beautiful glazed doors designed to maximize natural light and modern aesthetics.
</p>

            </div>

            <!-- Right Image -->
            <div class="col-lg-7 mt-5 mt-lg-0">

                <div class="door-image">
    <a id="doorImageLink" href="glazed-doors.html">
        <img id="doorImage"
             src="<?php echo get_template_directory_uri(); ?>/assets/images/glazed-door.jpg"
             alt="Door"
             class="img-fluid">
    </a>
</div>

            </div>

        </div>

    </div>
</section>


<section class="faq-section py-10">
    <div class="container">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-5">

            <h2 class="section-title mb-0">
                Frequently Asked Questions
            </h2>

            <a href="#" class="faq-link">
                Read FAQs
                <span>›</span>
            </a>

        </div>

        <!-- Accordion -->
        <div class="accordion custom-faq" id="faqAccordion">

            <!-- Item 1 -->
            <div class="accordion-item">

                <h2 class="accordion-header">
                    <button class="accordion-button"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq1">

                        Are Our Doors Pre-Hung?
                    </button>
                </h2>

                <div id="faq1"
                     class="accordion-collapse collapse show"
                     data-bs-parent="#faqAccordion">

                    <div class="accordion-body">
                        No, our doors are just the door itself.
                    </div>

                </div>

            </div>

            <!-- Item 2 -->
            <div class="accordion-item">

                <h2 class="accordion-header">
                    <button class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq2">

                        Do you offer installation?
                    </button>
                </h2>

                <div id="faq2"
                     class="accordion-collapse collapse"
                     data-bs-parent="#faqAccordion">

                    <div class="accordion-body">
                        Installation services vary by location.
                    </div>

                </div>

            </div>

            <!-- Item 3 -->
            <div class="accordion-item">

                <h2 class="accordion-header">
                    <button class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq3">

                        How long will my order take to ship?
                    </button>
                </h2>

                <div id="faq3"
                     class="accordion-collapse collapse"
                     data-bs-parent="#faqAccordion">

                    <div class="accordion-body">
                        Shipping times depend on stock availability.
                    </div>

                </div>

            </div>

            <!-- Item 4 -->
            <div class="accordion-item">

                <h2 class="accordion-header">
                    <button class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq4">

                        Do your doors come with hardware?
                    </button>
                </h2>

                <div id="faq4"
                     class="accordion-collapse collapse"
                     data-bs-parent="#faqAccordion">

                    <div class="accordion-body">
                        Hardware is generally sold separately.
                    </div>

                </div>

            </div>

        </div>

    </div>
</section>

<section class="feature-section">
    <div class="container-fluid p-0">

        <div class="row g-0">

            <div class="col">
                <div class="feature-box">
                    <i class="bi bi-tree"></i>
                    <h4>Quality Timber</h4>
                </div>
            </div>

            <div class="col">
                <div class="feature-box">
                    <i class="bi bi-heart"></i>
                    <h4>Loved By Customers</h4>
                </div>
            </div>

            <div class="col">
                <div class="feature-box">
                    <i class="bi bi-flower1"></i>
                    <h4>Natural Clean Timber</h4>
                </div>
            </div>

            <div class="col">
                <div class="feature-box">
                    <i class="bi bi-water"></i>
                    <h4>Environmentally Sustainable</h4>
                </div>
            </div>

            <div class="col">
                <div class="feature-box border-0">
                    <i class="bi bi-patch-check"></i>
                    <h4>Verified Suppliers</h4>
                </div>
            </div>

        </div>

    </div>
</section>

<?php get_footer(); ?>