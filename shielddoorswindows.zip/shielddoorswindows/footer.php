<footer class="custom-footer">

    <!-- Top Footer -->
    <div class="footer-top">
        <div class="container">

            <div class="row gy-5">

                <!-- About -->
                <div class="col-lg-3 col-md-6">
                    <h4>Shield Doors & Windows</h4>

                    <p>
                        At Shield Doors & Windows, we make it easy to get
                        great-looking, long-lasting doors and windows—without
                        paying “middle man” prices. With locations in Queensland,
                        Victoria, and Tasmania.
                    </p>
                </div>

                <!-- Links -->
                <div class="col-lg-2 col-md-6">
                    <h4>Quick links</h4>

                    <ul class="footer-links">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Internal Doors</a></li>
                        <li><a href="#">External Doors</a></li>
                        <li><a href="#">About Shield</a></li>
                        <li><a href="#">Installation Guides</a></li>
                        <li><a href="#">Blogs</a></li>
                    </ul>
                </div>

                <!-- Contact -->
                <div class="col-lg-3 col-md-6">
                    <h4>Contact info</h4>

                    <p>
                        Need to talk with our expert staff?
                        Tap here to get the help you need.
                    </p>
                </div>

                <!-- Newsletter -->
                <div class="col-lg-4 col-md-6">
                    <h4>Stay Updated</h4>

                    <p>
                        Subscribe to get special offers, free giveaways,
                        and once-in-a-lifetime deals.
                    </p>

                    <form>
                        <input type="email"
                               class="form-control footer-input"
                               placeholder="Your E-mail">

                        <button class="footer-btn">
                            Subscribe
                        </button>
                    </form>

                    <small>
                        You can unsubscribe anytime. We respect your privacy
                        and never share your information.
                    </small>
                </div>

            </div>

        </div>
    </div>

    <!-- Middle Footer -->
    <div class="footer-middle">

        <div class="container">

            <div class="row align-items-center">

                <div class="col-lg-6 text-center text-lg-start">
                    <h5>Payment Available</h5>

                    <div class="payment-icons">

                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/amex.png" alt="">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/apple-pay.png" alt="">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/google-pay.png" alt="">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/master-card.png" alt="">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shop-pay.png" alt="">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/unionpay.png" alt="">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/visa.png" alt="">

                    </div>
                </div>

                <div class="col-lg-6 text-center text-lg-end mt-4 mt-lg-0">
                    <h5>Join Our Social Media</h5>
                </div>

            </div>

        </div>

    </div>

    <!-- Bottom Footer -->
    <div class="container">
    <div class="footer-bottom">

        <div class="footer-bottom-row">

            <div class="copyright">
                © 2026 Shield Doors & Windows.
            </div>

            <div class="follow-shop">
                <a href="#" class="shop-btn">
                    ♡ Follow on shop
                </a>
            </div>

        </div>

    </div>
</div>

</footer>


<!-- Search Modal -->
<div class="modal fade" id="searchModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-body p-4">

                <input
                    type="text"
                    id="live-search"
                    class="form-control"
                    placeholder="Search products...">

                <div id="search-results"></div>

            </div>

        </div>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>