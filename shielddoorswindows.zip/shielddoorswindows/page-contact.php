<?php
/*
Template Name: Contact Us
*/

get_header();
?>

<section class="contact-page py-5">
    <div class="container">

        <!-- Breadcrumb -->
        <nav class="mb-4">
            <a href="<?php echo home_url(); ?>">Home</a>
            /
            <span>Contact Us</span>
        </nav>

        <!-- Heading -->
        <div class="text-center mb-5">
            <h1>Use the form to contact us or scroll to view our contact numbers.</h1>
        </div>

        <div class="row">

            <!-- Contact Form -->
            <div class="col-lg-8 mx-auto">

                <div class="contact-form-wrapper p-4">

                    <h3 class="mb-4">Contact Us</h3>

                    <?php echo do_shortcode('[contact-form-7 id="e51451c" title="Shield"]'); ?>

                </div>

            </div>

        </div>

    </div>
</section>

<!-- Locations -->
<section class="locations py-5">
    <div class="container">

        <h2 class="mb-5">Contact Us</h2>

        <div class="row g-5">

            <!-- Brisbane -->
            <div class="col-lg-4">

                <div class="map-box mb-4">
                    <iframe
                        src="https://maps.google.com/maps?q=20%20Chrome%20Court%20Burpengary&t=&z=13&ie=UTF8&iwloc=&output=embed"
                        width="100%"
                        height="250"
                        style="border:0;"
                        loading="lazy">
                    </iframe>
                </div>

                <h3>Shield Doors and Windows – Brisbane</h3>

                <ul class="location-info list-unstyled">
                    <li><strong>Location:</strong><br>
                        20 Chrome Court<br>
                        Burpengary QLD 4505
                    </li>

                    <li class="mt-3">
                        <strong>Phone:</strong><br>
                        07 4520 7001
                    </li>

                    <li class="mt-3">
                        <strong>Email:</strong><br>
                        brisbane@shielddoorswindows.com.au
                    </li>
                </ul>

            </div>

            <!-- Hobart -->
            <div class="col-lg-4">

                <div class="map-box mb-4">
                    <iframe
                        src="https://maps.google.com/maps?q=10%20Kennedy%20Drive%20Cambridge&t=&z=13&ie=UTF8&iwloc=&output=embed"
                        width="100%"
                        height="250"
                        style="border:0;"
                        loading="lazy">
                    </iframe>
                </div>

                <h3>Shield Doors and Windows – Hobart</h3>

                <ul class="location-info list-unstyled">
                    <li>
                        <strong>Location:</strong><br>
                        10 Kennedy Drive<br>
                        Cambridge TAS 7170
                    </li>

                    <li class="mt-3">
                        <strong>Phone:</strong><br>
                        03 6234 4344
                    </li>

                    <li class="mt-3">
                        <strong>Email:</strong><br>
                        cambridge@shielddoorswindows.com.au
                    </li>
                </ul>

            </div>

            <!-- Melbourne -->
            <div class="col-lg-4">

                <div class="map-box mb-4">
                    <iframe
                        src="https://maps.google.com/maps?q=2%20Graystone%20Court%20Epping&t=&z=13&ie=UTF8&iwloc=&output=embed"
                        width="100%"
                        height="250"
                        style="border:0;"
                        loading="lazy">
                    </iframe>
                </div>

                <h3>Shield Doors and Windows – Melbourne</h3>

                <ul class="location-info list-unstyled">
                    <li>
                        <strong>Location:</strong><br>
                        2 Graystone Court<br>
                        Epping VIC 3076
                    </li>

                    <li class="mt-3">
                        <strong>Phone:</strong><br>
                        07 4520 7001
                    </li>

                    <li class="mt-3">
                        <strong>Email:</strong><br>
                        melbourne@shielddoorswindows.com.au
                    </li>
                </ul>

            </div>

        </div>

    </div>
</section>

<?php get_footer(); ?>