<?php
defined('ABSPATH') || exit;

get_header();

$term = get_queried_object();

$thumbnail_id = get_term_meta($term->term_id, 'thumbnail_id', true);
$banner = wp_get_attachment_url($thumbnail_id);
?>

<!-- CATEGORY BANNER -->
<section class="collection-banner">

    <?php if ($banner) : ?>
        <img src="<?php echo esc_url($banner); ?>" alt="<?php echo esc_attr($term->name); ?>">
    <?php endif; ?>

    <div class="banner-overlay">

        <div class="container">

            <div class="banner-breadcrumb">
                <a href="<?php echo home_url(); ?>">Home</a>
                <span>/</span>
                <span><?php echo esc_html($term->name); ?></span>
            </div>

            <h1><?php echo esc_html($term->name); ?></h1>

        </div>

    </div>

</section>

<div class="container py-5">

    <!-- MOBILE FILTER BUTTON -->
    <button
        class="btn btn-dark w-100 d-lg-none mb-4"
        data-bs-toggle="offcanvas"
        data-bs-target="#shopFilters">

        Filter & Sort

    </button>

    <div class="row">

        <!-- SIDEBAR -->
        <aside class="col-lg-3 d-none d-lg-block">

            <div class="shop-sidebar">

                <?php dynamic_sidebar('shop-sidebar'); ?>

            </div>

        </aside>

        <!-- PRODUCTS -->
        <div class="col-lg-9">

            <?php if (woocommerce_product_loop()) : ?>

                <div class="shop-toolbar d-flex justify-content-between align-items-center mb-4">

                    <div class="result-count">
                        <?php woocommerce_result_count(); ?>
                    </div>

                    <div class="sorting">
                        <?php woocommerce_catalog_ordering(); ?>
                    </div>

                </div>

                <ul class="products">

                    <?php while (have_posts()) : the_post(); ?>

                        <?php wc_get_template_part('content', 'product'); ?>

                    <?php endwhile; ?>

                </ul>

                <div class="shop-pagination mt-4">

                    <?php woocommerce_pagination(); ?>

                </div>

            <?php else : ?>

                <div class="alert alert-light">

                    No products found.

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

<!-- TOP PICKS -->
<section class="top-picks py-5">

    <div class="container">

        <h2 class="section-title mb-4">
            Our Customers Top Picks
        </h2>

        <?php echo do_shortcode('[products limit="4" visibility="featured"]'); ?>

    </div>

</section>

<!-- CATEGORY DESCRIPTION -->
<?php if (term_description()) : ?>

<section class="category-content py-5">

    <div class="container">

        <?php echo term_description(); ?>

    </div>

</section>

<?php endif; ?>

<!-- MOBILE FILTERS -->
<div
    class="offcanvas offcanvas-start"
    tabindex="-1"
    id="shopFilters">

    <div class="offcanvas-header">

        <h5 class="offcanvas-title">
            Filter Products
        </h5>

        <button
            type="button"
            class="btn-close"
            data-bs-dismiss="offcanvas">
        </button>

    </div>

    <div class="offcanvas-body">

        <?php dynamic_sidebar('shop-sidebar'); ?>

    </div>

</div>

<?php get_footer(); ?>