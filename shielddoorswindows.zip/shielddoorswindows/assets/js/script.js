// Sticky navbar on scroll

window.addEventListener("scroll", function () {

    const navbar = document.querySelector(".navbar");

    if (window.scrollY > 80) {
        navbar.classList.add("scrolled");
    } else {
        navbar.classList.remove("scrolled");
    }

});


// Active menu highlighting

const navLinks = document.querySelectorAll(".nav-link");

navLinks.forEach(link => {

    link.addEventListener("click", function(){

        navLinks.forEach(item => {
            item.classList.remove("active");
        });

        this.classList.add("active");

    });

});



// popular doors section
const links = document.querySelectorAll('.door-link');
const image = document.getElementById('doorImage');
const imageLink = document.getElementById('doorImageLink');
const description = document.querySelector('.door-description');

links.forEach(link => {

    link.addEventListener('mouseenter', function(){

        links.forEach(item => item.classList.remove('active'));
        this.classList.add('active');

        image.src = this.dataset.image;
        description.textContent = this.dataset.text;

        imageLink.href = this.href;
    });

});

// search icon
jQuery(document).ready(function($){

    $('#live-search').on('keyup', function(){

        let keyword = $(this).val();

        $.ajax({

            url: ajax_object.ajax_url,

            type: 'POST',

            data: {
                action: 'live_product_search',
                keyword: keyword
            },

            success: function(response){

                $('#search-results').html(response);

            }

        });

    });

});

