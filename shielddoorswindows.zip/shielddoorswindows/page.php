<?php
get_header();
?>

<section class="page">
    <div class="container py-5">
        <?php
        while (have_posts()) :
            the_post();
            the_content();
        endwhile;
        ?>
    </div>
</section>

<?php
get_footer();
?>