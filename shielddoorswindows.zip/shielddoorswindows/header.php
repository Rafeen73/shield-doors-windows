<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shield Doors & Windows</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <?php wp_head(); ?>
</head>
<body>

    <!-- Top Bar -->
    <div class="top-bar">
        <div class="container">
            Free national shipping enabled for all orders over <strong>$550</strong> on Timber Doors (Online Only)
        </div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg <?php echo is_front_page() ? 'navbar-home' : 'navbar-inner'; ?>">
    
        <div class="container">

            <!-- Logo -->
            <a class="navbar-brand" href="<?php echo home_url(); ?>">
                SHIELD
            </a>

            <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarMenu">

                <?php
wp_nav_menu([
    'theme_location' => 'primary',
    'container' => false,
    'menu_class' => 'navbar-nav mx-auto'
]);
?>

                 <div class="nav-icons">

    <!-- Search -->
    <a href="#" data-bs-toggle="modal" data-bs-target="#searchModal">
        <i class="bi bi-search"></i>
    </a>
    <!-- My Account -->
    <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="account-icon">
        <i class="bi bi-person"></i>
    </a>

    <!-- Cart -->
    <a href="<?php echo wc_get_cart_url(); ?>" class="cart-icon">
        <i class="bi bi-bag"></i>

        <span class="cart-count">
            <?php echo WC()->cart->get_cart_contents_count(); ?>
        </span>
    </a>

</div>
            </div>

        </div>
    </nav>
