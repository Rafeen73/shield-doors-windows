<?php

function shield_theme_setup() {

    add_theme_support('title-tag');

    add_theme_support('post-thumbnails');

    register_nav_menus([
        'primary' => __('Primary Menu', 'shield')
    ]);
}

add_action('after_setup_theme', 'shield_theme_setup');


function shield_enqueue_assets() {

    wp_enqueue_style(
        'bootstrap',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'
    );

    wp_enqueue_style(
        'bootstrap-icons',
        'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css'
    );

    wp_enqueue_style(
        'google-fonts',
        'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap'
    );

    wp_enqueue_style(
        'shield-style',
        get_template_directory_uri() . '/assets/css/custom.css',
        [],
        filemtime(get_template_directory() . '/assets/css/custom.css')
    );

     wp_enqueue_style(
        'shield-responsive',
        get_template_directory_uri() . '/assets/css/responsive.css',
        ['shield-style'], // Optional dependency
        filemtime(get_template_directory() . '/assets/css/responsive.css')
    );

    wp_enqueue_script(
        'bootstrap-js',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',
        [],
        null,
        true
    );

    wp_enqueue_script(
        'shield-script',
        get_template_directory_uri() . '/assets/js/script.js',
        [],
        null,
        true
    );
}

add_action('wp_enqueue_scripts', 'shield_enqueue_assets');

//  request for quote button 
add_action('woocommerce_after_add_to_cart_button', 'shield_quote_button');

function shield_quote_button() {
    echo '<a href="/contact-us" class="quote-btn">Request for Quote</a>';
}

// custom stock badge
add_filter('woocommerce_get_availability_text', function($availability, $product){

    if ($product->is_in_stock() && $product->managing_stock()) {
        return $product->get_stock_quantity() . ' Items In Stock';
    }

    return $availability;

}, 10, 2);

// nav icon add to cart
add_filter('woocommerce_add_to_cart_fragments', function($fragments){

    ob_start(); ?>
    
    <span class="cart-count">
        <?php echo WC()->cart->get_cart_contents_count(); ?>
    </span>

    <?php

    $fragments['.cart-count'] = ob_get_clean();

    return $fragments;
});

// search ajax handler
add_action('wp_ajax_live_product_search', 'live_product_search');
add_action('wp_ajax_nopriv_live_product_search', 'live_product_search');

function live_product_search() {

    $keyword = sanitize_text_field($_POST['keyword']);

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 10,
        's' => $keyword
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {

        while ($query->have_posts()) {

            $query->the_post();

            echo '<a class="search-item" href="' . get_permalink() . '">';
            echo get_the_title();
            echo '</a>';

        }

    } else {

        echo '<p>No products found.</p>';

    }

    wp_die();
}

// ajax url
function theme_scripts() {

    wp_enqueue_script(
        'script-js',
        get_template_directory_uri() . '/js/script.js',
        array('jquery'),
        null,
        true
    );

    wp_localize_script(
        'script-js',
        'ajax_object',
        array(
            'ajax_url' => admin_url('admin-ajax.php')
        )
    );
}

add_action('wp_enqueue_scripts', 'theme_scripts');

// register shop sidebar
function shield_shop_sidebar() {

    register_sidebar(array(
        'name' => 'Shop Sidebar',
        'id' => 'shop-sidebar',
        'before_widget' => '<div class="filter-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h5 class="filter-title">',
        'after_title' => '</h5>',
    ));

}
add_action('widgets_init','shield_shop_sidebar');


// put in functions.php temporarily
add_filter('template_include', function($template){

    if (is_product_category()) {
        return get_template_directory() . '/taxonomy-product_cat.php';
    }

    return $template;
});