<section class="single-product">
<div class="container py-5">
    <div class="row g-5 align-items-start">

        <div class="col-lg-6">
            <?php do_action('woocommerce_before_single_product_summary'); ?>
        </div>

        <div class="col-lg-6">
            <?php do_action('woocommerce_single_product_summary'); ?>
        </div>

    </div>
</div>
</section>