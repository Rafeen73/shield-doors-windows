<?php
defined('ABSPATH') || exit;

global $product;

if (empty($product) || !$product->is_visible()) {
    return;
}
?>

<li <?php wc_product_class('product-item'); ?>>

    <div class="product-card">

        <a href="<?php the_permalink(); ?>">

            <div class="product-image">

                <?php echo woocommerce_get_product_thumbnail('woocommerce_thumbnail'); ?>

            </div>

            <div class="product-info">

                <h3><?php the_title(); ?></h3>

                <span class="price">
                    <?php echo $product->get_price_html(); ?>
                </span>

            </div>

        </a>

    </div>

</li>