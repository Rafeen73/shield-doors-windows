<?php
/*
Template Name: Best Sellers
*/

get_header();
?>

<!-- Banner -->
<section class="collection-banner">
    <div class="banner-overlay">
        <div class="container">
            
            <div class="banner-breadcrumb">
                <a href="<?php echo home_url(); ?>">Home</a>
                <span>/</span>
                <span>Best Sellers</span>
            </div>

            <h1>Best Sellers</h1>

        </div>
    </div>
</section>

<!-- Featured Products -->
<section class="bestsellers-section py-5">
    <div class="container">

        <div class="row">

        <?php

        $featured = new WP_Query(array(
            'post_type'      => 'product',
            'tax_query'      => array(
                array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => 'featured',
                ),
            ),
        ));

        while ($featured->have_posts()) :
            $featured->the_post();

            global $product;
        ?>

            <div class="col-lg-3 col-md-6">

                    <div class="card product-card h-100 border-0">

                        <a href="<?php the_permalink(); ?>">

                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium', array(
                                    'class' => 'card-img-top img-fluid'
                                )); ?>
                            <?php endif; ?>

                        </a>

                        <div class="card-body text-center">

                            <h5 class="product-title>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h5>

                            <div class="product-price">
                                <?php echo $product->get_price_html(); ?>
                            </div>

                        </div>

                    </div>

                </div>

        <?php endwhile; wp_reset_postdata(); ?>

        </div>

    </div>
</section>

<!-- Customers Top Picks -->
<section class="top-picks py-5">
    <div class="container">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Our Customers Top Picks</h2>

            <a href="<?php echo site_url('/best-sellers/'); ?>" class="btn btn-outline-dark">
                Explore More
            </a>
        </div>

        <div class="row">

        <?php

        $products = new WP_Query(array(
            'post_type'      => 'product',
            'posts_per_page' => 4
        ));

        while ($products->have_posts()) :
            $products->the_post();

            global $product;
        ?>

            <div class="col-lg-3 col-md-6">

                    <div class="card product-card h-100 border-0">

                        <a href="<?php the_permalink(); ?>">

                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium', array(
                                    'class' => 'card-img-top img-fluid'
                                )); ?>
                            <?php endif; ?>

                        </a>

                        <div class="card-body text-center">

                            <h5 class="product-title>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h5>

                            <div class="product-price">
                                <?php echo $product->get_price_html(); ?>
                            </div>

                        </div>

                    </div>

                </div>

        <?php endwhile; wp_reset_postdata(); ?>

        </div>

    </div>
</section>

<?php get_footer(); ?>